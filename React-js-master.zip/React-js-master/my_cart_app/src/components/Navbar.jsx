import React from "react";
function Navbar() {
  return (
    <div>
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container-fluid">
          <a class="navbar-brand" href="#">
            My CART
          </a>
         
        </div>
      </nav>
    </div>
  );
}

export default Navbar;
