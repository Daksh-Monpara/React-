import { useState } from 'react'
import './App.css'
import Useeffect from './useEffect'

function App() {
 

  return (
    <>
     <Useeffect/>
    </>
  )
}

export default App
